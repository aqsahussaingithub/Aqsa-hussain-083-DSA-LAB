//Recursive linear Search
/*#include <iostream>
using namespace std;

int recursiveLinearSearch(int arr[], int start, int end, int target) {
    if (start > end) {
        return -1; // Base case: element not found
    }
    if (arr[start] == target) {
        return start; // Base case: element found at current index
    }
    return recursiveLinearSearch(arr, start + 1, end, target); // Recursive call to search in the remaining array
}

int main() {
	
  int size ;
  cout<<"enter the size of array ";
  cin>>size;
  
  int arr[size];
  cout<<"enter the elements for array"<<endl;
  for (int i=0; i<size ; i++) {
  	cin>>arr[i];
  }
  
  int target ;
  cout<<"enter the target element";
  cin>>target;
  
    
    int result = recursiveLinearSearch(arr, 0, size - 1, target);
    
    if (result == -1) {
        cout << "Element not found." << endl;
    } else {
        cout << "Element found at index " << result << "." << endl;
    }
    
    return 0;
}*/

//non recursive function
/*#include <iostream>
using namespace std;

int linearSearch(int arr[], int size, int target) {
    for (int i = 0; i < size; i++) {
        if (arr[i] == target) {
            return i; // Element found, return the index
        }
    }
    return -1; // Element not found
}

int main() {
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;

    int arr[size];
    cout << "Enter the elements of the array: ";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    int target;
    cout << "Enter the target element: ";
    cin >> target;

    int result = linearSearch(arr, size, target);

    if (result == -1) {
        cout << "Element not found." << endl;
    } else {
        cout << "Element found at index " << result << "." << endl;
    }

    return 0;
}*/







